import { MovieDetails, MovieSummary, SummaryMode } from '@/types/movie';

type RestPage = {
  id: number;
  key: string;
  title: string;
  excerpt?: string;
  description?: string | null;
  thumbnail?: { url?: string } | null;
};

const WIKI_REST = 'https://de.wikipedia.org/w/rest.php/v1';
const cache = new Map<number, MovieSummary>();

async function getJson(url: string) {
  const response = await fetch(url, {
    headers: {
      Accept: 'application/json',
      'Api-User-Agent': 'SEEN/0.3.5 (https://github.com/Viktor9311/seen-app)',
    },
  });
  if (!response.ok) throw new Error(`Movie service error (${response.status})`);
  return response.json();
}

function cleanText(input?: string | null) {
  return String(input || '')
    .replace(/<span[^>]*>/gi, '')
    .replace(/<\/span>/gi, '')
    .replace(/<[^>]+>/g, '')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&')
    .trim();
}

function imageUrl(url?: string | null) {
  if (!url) return null;
  return url.startsWith('//') ? `https:${url}` : url;
}

function yearFrom(page: RestPage): string | null {
  const text = `${page.title} ${page.description || ''} ${page.excerpt || ''}`;
  const match = text.match(/\b(19\d{2}|20\d{2})\b/);
  return match ? `${match[1]}-01-01` : null;
}

function overviewFrom(page: RestPage) {
  const description = cleanText(page.description);
  const excerpt = cleanText(page.excerpt);
  if (description && excerpt && !excerpt.toLowerCase().includes(description.toLowerCase())) {
    return `${description}. ${excerpt}`;
  }
  return excerpt || description;
}

function toSummary(page: RestPage): MovieSummary {
  const movie: MovieSummary = {
    id: page.id,
    title: page.title.replace(/\s*\(Film(?:,.*)?\)\s*$/i, ''),
    releaseDate: yearFrom(page),
    posterPath: imageUrl(page.thumbnail?.url),
    backdropPath: imageUrl(page.thumbnail?.url),
    overview: overviewFrom(page),
  };
  cache.set(movie.id, movie);
  return movie;
}

function likelyFilm(page: RestPage) {
  const text = `${page.title} ${page.description || ''} ${page.excerpt || ''}`;
  return /(film|spielfilm|filmdrama|actionfilm|thriller|komödie|horrorfilm|science-fiction|animationsfilm|kinofilm|western|movie)/i.test(text);
}

async function restSearch(query: string, limit = 20): Promise<RestPage[]> {
  const url = `${WIKI_REST}/search/page?q=${encodeURIComponent(query)}&limit=${limit}`;
  const data = await getJson(url);
  return Array.isArray(data?.pages) ? data.pages : [];
}

export async function searchMovies(query: string): Promise<MovieSummary[]> {
  const q = query.trim();
  if (!q) return [];

  const pages = await restSearch(`${q} Film`, 20);
  const films = pages.filter(likelyFilm);
  const chosen = films.length ? films : pages;
  return chosen.slice(0, 15).map(toSummary);
}

export async function popularMovies(): Promise<MovieSummary[]> {
  const titles = ['Dune', 'Interstellar', 'Gladiator', 'The Dark Knight'];
  const batches = await Promise.all(
    titles.map(async (title) => {
      try {
        const found = await searchMovies(title);
        return found[0] ?? null;
      } catch {
        return null;
      }
    })
  );
  return batches.filter(Boolean) as MovieSummary[];
}

export async function getMovieDetails(id: number, title?: string): Promise<MovieDetails> {
  let base = cache.get(id) || null;

  if (!base && title) {
    const pages = await restSearch(`${title} Film`, 12);
    const page = pages.find((p) => p.id === id) || pages.find(likelyFilm) || pages[0];
    if (page) base = toSummary(page);
  }

  if (!base) throw new Error('Film details could not be loaded. Please open the film from Search again.');

  return {
    ...base,
    runtime: null,
    genres: [],
    director: null,
    tmdbRating: null,
  };
}

export async function getAiSummary(id: number, mode: SummaryMode, title?: string): Promise<string> {
  const movie = await getMovieDetails(id, title);
  const overview = movie.overview?.trim();
  if (!overview) return 'Für diesen Film ist aktuell noch keine Zusammenfassung verfügbar.';
  if (mode === 'spoiler_free') return overview;
  if (mode === 'spoiler') return `${overview}\n\nDie ausführliche SEEN-AI-Spoilerzusammenfassung wird in einem späteren Build aktiviert.`;
  return `${overview}\n\nDie Funktion „Ende erklären“ wird im nächsten SEEN-AI-Ausbauschritt aktiviert.`;
}
