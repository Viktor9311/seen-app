import { MovieDetails, MovieSummary, SummaryMode } from '@/types/movie';

type WikiPage = {
  pageid: number;
  title: string;
  extract?: string;
  thumbnail?: { source?: string };
  index?: number;
};

const WIKI_API = 'https://de.wikipedia.org/w/api.php';

async function getJson(url: string) {
  const response = await fetch(url, {
    headers: {
      Accept: 'application/json',
      'Api-User-Agent': 'SEEN/0.3.4 (https://github.com/Viktor9311/seen-app)',
    },
  });
  if (!response.ok) throw new Error(`Movie service error (${response.status})`);
  return response.json();
}

function yearFrom(page: WikiPage): string | null {
  const text = `${page.title} ${page.extract || ''}`;
  const match = text.match(/\b(19\d{2}|20\d{2})\b/);
  return match ? `${match[1]}-01-01` : null;
}

function toSummary(page: WikiPage): MovieSummary {
  return {
    id: page.pageid,
    title: page.title.replace(/\s*\(Film\)\s*$/i, ''),
    releaseDate: yearFrom(page),
    posterPath: page.thumbnail?.source || null,
    backdropPath: page.thumbnail?.source || null,
    overview: page.extract || '',
  };
}

function likelyFilm(page: WikiPage) {
  const text = `${page.title} ${page.extract || ''}`;
  return /(film|spielfilm|filmdrama|actionfilm|thriller|komödie|horrorfilm|science-fiction|animationsfilm|kinofilm|western)/i.test(text);
}

export async function searchMovies(query: string): Promise<MovieSummary[]> {
  const q = query.trim();
  if (!q) return [];

  const params = [
    'action=query',
    'generator=search',
    `gsrsearch=${encodeURIComponent(`${q} Film`)}`,
    'gsrnamespace=0',
    'gsrlimit=20',
    'prop=pageimages%7Cextracts',
    'piprop=thumbnail',
    'pithumbsize=500',
    'exintro=1',
    'explaintext=1',
    'exsentences=3',
    'format=json',
    'formatversion=2',
    'origin=*',
  ].join('&');

  const data = await getJson(`${WIKI_API}?${params}`);
  const pages = ((data?.query?.pages ?? []) as WikiPage[])
    .filter((p) => p?.pageid && p?.title)
    .sort((a, b) => (a.index ?? 9999) - (b.index ?? 9999));

  const films = pages.filter(likelyFilm);
  const chosen = films.length ? films : pages;
  return chosen.slice(0, 15).map(toSummary);
}

export async function popularMovies(): Promise<MovieSummary[]> {
  const titles = ['Dune', 'Interstellar', 'Gladiator', 'The Dark Knight'];
  const batches = await Promise.all(
    titles.map(async (title) => {
      try {
        const found = await searchMovies(title);
        return found[0] ?? null;
      } catch {
        return null;
      }
    })
  );
  return batches.filter(Boolean) as MovieSummary[];
}

export async function getMovieDetails(id: number): Promise<MovieDetails> {
  const params = [
    'action=query',
    `pageids=${id}`,
    'prop=pageimages%7Cextracts',
    'piprop=thumbnail',
    'pithumbsize=700',
    'explaintext=1',
    'exsectionformat=plain',
    'format=json',
    'formatversion=2',
    'origin=*',
  ].join('&');

  const data = await getJson(`${WIKI_API}?${params}`);
  const page = (data?.query?.pages ?? [])[0] as WikiPage | undefined;
  if (!page || page.pageid === -1) throw new Error('Film wurde nicht gefunden.');

  const base = toSummary(page);
  return {
    ...base,
    runtime: null,
    genres: [],
    director: null,
    tmdbRating: null,
  };
}

export async function getAiSummary(id: number, mode: SummaryMode): Promise<string> {
  const movie = await getMovieDetails(id);
  const overview = movie.overview?.trim();
  if (!overview) return 'Für diesen Film ist aktuell noch keine Zusammenfassung verfügbar.';
  if (mode === 'spoiler_free') return overview;
  if (mode === 'spoiler') return `${overview}\n\nDie ausführliche SEEN-AI-Spoilerzusammenfassung wird in einem späteren Build aktiviert.`;
  return `${overview}\n\nDie Funktion „Ende erklären“ wird im nächsten SEEN-AI-Ausbauschritt aktiviert.`;
}
