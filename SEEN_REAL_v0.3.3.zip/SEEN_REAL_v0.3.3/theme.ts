export const colors = {
  bg: '#090B0C',
  surface: '#121517',
  surface2: '#181C1F',
  border: '#272D30',
  text: '#F4F6F5',
  muted: '#8D969A',
  lime: '#C9FF3D',
  black: '#070909',
  danger: '#E98A8A',
};
