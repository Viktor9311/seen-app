export type MovieSummary = {
  id: number;
  title: string;
  releaseDate: string | null;
  posterPath: string | null;
  backdropPath?: string | null;
  overview?: string;
  communityRating?: number | null;
  communityRatingCount?: number;
};

export type MovieDetails = MovieSummary & {
  runtime: number | null;
  genres: string[];
  director: string | null;
  tmdbRating: number | null;
};

export type LibraryEntry = {
  id: number;
  user_id: string;
  tmdb_id: number;
  title: string;
  poster_path: string | null;
  release_date: string | null;
  status: 'seen' | 'watchlist';
  user_rating: number | null;
  watched_at: string | null;
  where_watched: string | null;
  note: string | null;
  created_at: string;
  updated_at: string;
};

export type SummaryMode = 'spoiler_free' | 'spoiler' | 'ending';
