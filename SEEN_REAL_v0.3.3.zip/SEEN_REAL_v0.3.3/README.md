# SEEN v0.3.1 — Android-ready source

Diese Version ist bereits mit dem SEEN-Supabase-Projekt verbunden.

## Enthalten
- Supabase Login/Registrierung
- Cloud-Speicherung für My Movies und Watchlist
- Filmsuche ohne zusätzlichen API-Key (Apple/iTunes Movie Catalog)
- Poster, Laufzeit, Genre, Beschreibung
- Rating 1–10, Datum, Ort/Plattform und Notiz
- Community-Rating über Supabase
- dunkles SEEN-Design mit Lime-Akzent
- EAS `preview` Profil erzeugt eine direkt installierbare Android-APK

## APK bauen
1. Expo-Konto erstellen / anmelden.
2. Im Projektordner: `npm install`
3. `npx eas-cli login`
4. `npx eas-cli build:configure`
5. `npx eas-cli build --platform android --profile preview`
6. Nach dem Cloud-Build den angezeigten Installationslink auf dem Android-Handy öffnen.

Die Werte in `.env` und `eas.json` sind Supabase-Publishable-Werte und für Client-Apps vorgesehen. Keine Secret-/Service-Role-Keys eintragen.
