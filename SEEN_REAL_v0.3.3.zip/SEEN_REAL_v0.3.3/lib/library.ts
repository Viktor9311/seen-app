import { supabase } from '@/lib/supabase';
import { LibraryEntry, MovieSummary } from '@/types/movie';

function client() {
  if (!supabase) throw new Error('SEEN is not connected to Supabase yet.');
  return supabase;
}

export async function getLibrary(status?: 'seen' | 'watchlist'): Promise<LibraryEntry[]> {
  let query = client().from('user_movies').select('*').order('updated_at', { ascending: false });
  if (status) query = query.eq('status', status);
  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []) as LibraryEntry[];
}

export async function getEntry(tmdbId: number): Promise<LibraryEntry | null> {
  const { data, error } = await client()
    .from('user_movies')
    .select('*')
    .eq('tmdb_id', tmdbId)
    .maybeSingle();
  if (error) throw error;
  return data as LibraryEntry | null;
}

export async function saveSeen(params: {
  movie: MovieSummary;
  rating: number;
  watchedAt: string;
  whereWatched: string;
  note: string;
}) {
  const { data: userData, error: userError } = await client().auth.getUser();
  if (userError || !userData.user) throw userError ?? new Error('Not signed in');

  const { error } = await client().from('user_movies').upsert({
    user_id: userData.user.id,
    tmdb_id: params.movie.id,
    title: params.movie.title,
    poster_path: params.movie.posterPath,
    release_date: params.movie.releaseDate ? params.movie.releaseDate.slice(0, 10) : null,
    status: 'seen',
    user_rating: params.rating,
    watched_at: params.watchedAt,
    where_watched: params.whereWatched,
    note: params.note || null,
    updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id,tmdb_id' });
  if (error) throw error;
}

export async function saveWatchlist(movie: MovieSummary) {
  const { data: userData, error: userError } = await client().auth.getUser();
  if (userError || !userData.user) throw userError ?? new Error('Not signed in');

  const { error } = await client().from('user_movies').upsert({
    user_id: userData.user.id,
    tmdb_id: movie.id,
    title: movie.title,
    poster_path: movie.posterPath,
    release_date: movie.releaseDate ? movie.releaseDate.slice(0, 10) : null,
    status: 'watchlist',
    user_rating: null,
    watched_at: null,
    where_watched: null,
    note: null,
    updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id,tmdb_id' });
  if (error) throw error;
}

export async function removeEntry(tmdbId: number) {
  const { error } = await client().from('user_movies').delete().eq('tmdb_id', tmdbId);
  if (error) throw error;
}

export async function getCommunityRating(tmdbId: number) {
  const { data, error } = await client().rpc('get_community_rating', { movie_id: tmdbId });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return {
    average: row?.average_rating ? Number(row.average_rating) : null,
    count: row?.rating_count ? Number(row.rating_count) : 0,
  };
}
