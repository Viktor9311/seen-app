export const posterUrl = (path?: string | null, width: 'w342' | 'w500' = 'w500') => {
  if (!path) return null;
  if (/^https?:\/\//i.test(path)) return path;
  return `https://image.tmdb.org/t/p/${width}${path}`;
};

export const backdropUrl = (path?: string | null) => {
  if (!path) return null;
  if (/^https?:\/\//i.test(path)) return path;
  return `https://image.tmdb.org/t/p/w780${path}`;
};
