import { SafeAreaView } from 'react-native-safe-area-context';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { colors } from '@/theme';

export default function SetupScreen() {
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.logo}>SEEN</Text>
        <Text style={styles.title}>Backend noch nicht verbunden.</Text>
        <Text style={styles.body}>Lege eine .env-Datei an und trage dort die zwei öffentlichen Supabase-Werte ein. Die Vorlage liegt als .env.example im Projekt.</Text>
        <View style={styles.code}><Text style={styles.codeText}>EXPO_PUBLIC_SUPABASE_URL=…{`\n`}EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=…</Text></View>
        <Text style={styles.body}>Danach Expo neu starten. Die Filmsuche läuft in dieser Version direkt über einen öffentlichen Filmkatalog; zusätzliche API-Schlüssel sind nicht nötig.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg }, content: { padding: 24 }, logo: { color: colors.text, fontSize: 30, fontWeight: '900', letterSpacing: 4, marginBottom: 36 }, title: { color: colors.text, fontSize: 28, fontWeight: '900' }, body: { color: colors.muted, lineHeight: 22, marginTop: 14 }, code: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, padding: 16, borderRadius: 14, marginTop: 20 }, codeText: { color: colors.lime, fontFamily: 'monospace', fontSize: 12, lineHeight: 20 },
});
