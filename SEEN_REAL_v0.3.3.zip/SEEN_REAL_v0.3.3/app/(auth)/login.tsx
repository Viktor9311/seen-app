import { router } from 'expo-router';
import { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { supabase } from '@/lib/supabase';
import { colors } from '@/theme';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);

  async function signIn() {
    if (!supabase) return;
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setBusy(false);
    if (error) return Alert.alert('Login', error.message);
    router.replace('/(tabs)');
  }

  async function signUp() {
    if (!supabase) return;
    if (password.length < 6) return Alert.alert('Password', 'Use at least 6 characters.');
    setBusy(true);
    const { data, error } = await supabase.auth.signUp({ email: email.trim(), password });
    setBusy(false);
    if (error) return Alert.alert('Sign up', error.message);
    if (!data.session) Alert.alert('Check your email', 'Confirm your email, then sign in.');
    else router.replace('/(tabs)');
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.content}>
          <Text style={styles.logo}>SEEN</Text>
          <Text style={styles.kicker}>YOUR MOVIE MEMORY</Text>
          <Text style={styles.title}>Remember what you watched.</Text>
          <TextInput value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="Email" placeholderTextColor={colors.muted} style={styles.input} />
          <TextInput value={password} onChangeText={setPassword} secureTextEntry placeholder="Password" placeholderTextColor={colors.muted} style={styles.input} />
          <Pressable style={styles.primary} onPress={signIn} disabled={busy}><Text style={styles.primaryText}>{busy ? 'Please wait…' : 'Sign in'}</Text></Pressable>
          <Pressable style={styles.secondary} onPress={signUp} disabled={busy}><Text style={styles.secondaryText}>Create account</Text></Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg }, flex: { flex: 1 }, content: { flex: 1, justifyContent: 'center', padding: 24 }, logo: { color: colors.text, fontSize: 34, fontWeight: '900', letterSpacing: 5 }, kicker: { color: colors.lime, fontSize: 10, fontWeight: '900', letterSpacing: 2, marginTop: 10 }, title: { color: colors.text, fontSize: 30, lineHeight: 35, fontWeight: '900', marginTop: 22, marginBottom: 28 }, input: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 14, color: colors.text, padding: 15, marginBottom: 11 }, primary: { backgroundColor: colors.lime, borderRadius: 14, padding: 15, alignItems: 'center', marginTop: 5 }, primaryText: { color: colors.black, fontWeight: '900' }, secondary: { borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: 15, alignItems: 'center', marginTop: 10 }, secondaryText: { color: colors.text, fontWeight: '800' },
});
