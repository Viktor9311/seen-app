import { Image } from 'expo-image';
import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { useCallback, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getAiSummary, getMovieDetails } from '@/lib/api';
import { backdropUrl, posterUrl } from '@/lib/images';
import { getCommunityRating, getEntry, removeEntry, saveWatchlist } from '@/lib/library';
import { colors } from '@/theme';
import { LibraryEntry, MovieDetails, SummaryMode } from '@/types/movie';

export default function MovieScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const movieId = Number(id);
  const [movie, setMovie] = useState<MovieDetails | null>(null);
  const [entry, setEntry] = useState<LibraryEntry | null>(null);
  const [community, setCommunity] = useState<{average:number|null; count:number}>({ average: null, count: 0 });
  const [summary, setSummary] = useState('');
  const [summaryMode, setSummaryMode] = useState<SummaryMode>('spoiler_free');
  const [aiBusy, setAiBusy] = useState(false);

  useFocusEffect(useCallback(() => {
    getMovieDetails(movieId).then(setMovie).catch((e) => Alert.alert('Movie', e.message));
    getEntry(movieId).then(setEntry).catch(() => setEntry(null));
    getCommunityRating(movieId).then(setCommunity).catch(() => setCommunity({ average: null, count: 0 }));
  }, [movieId]));

  async function addWatchlist() {
    if (!movie) return;
    await saveWatchlist(movie);
    setEntry(await getEntry(movieId));
  }
  async function remove() {
    await removeEntry(movieId); setEntry(null);
  }
  async function loadAi(mode: SummaryMode) {
    setSummaryMode(mode); setAiBusy(true);
    try { setSummary(await getAiSummary(movieId, mode)); }
    catch (e: any) { Alert.alert('SEEN AI', e?.message || 'Could not load summary.'); }
    finally { setAiBusy(false); }
  }

  if (!movie) return <SafeAreaView style={styles.safe}><Text style={styles.loading}>Loading movie…</Text></SafeAreaView>;
  const back = backdropUrl(movie.backdropPath); const poster = posterUrl(movie.posterPath);
  return (
    <View style={styles.safe}>
      <ScrollView contentContainerStyle={{ paddingBottom: 50 }}>
        <View style={styles.hero}>{back ? <Image source={back} style={StyleSheet.absoluteFill} contentFit="cover" /> : null}<View style={styles.overlay} /><SafeAreaView><Pressable style={styles.back} onPress={() => router.back()}><Text style={styles.backText}>‹</Text></Pressable></SafeAreaView></View>
        <View style={styles.body}>
          <View style={styles.heading}>{poster ? <Image source={poster} style={styles.poster} contentFit="cover" /> : null}<View style={styles.headingInfo}><Text style={styles.title}>{movie.title}</Text><Text style={styles.meta}>{movie.releaseDate?.slice(0,4) || '—'} · {movie.runtime || '—'} min</Text><Text style={styles.meta}>{movie.genres.join(' · ')}</Text>{movie.director ? <Text style={styles.director}>Directed by {movie.director}</Text> : null}</View></View>
          <View style={styles.ratings}><View style={styles.ratingCard}><Text style={styles.ratingValue}>{entry?.user_rating ? Number(entry.user_rating).toFixed(1) : '–'}</Text><Text style={styles.ratingLabel}>YOUR RATING</Text></View><View style={styles.ratingCard}><Text style={styles.ratingValue}>{community.average ? community.average.toFixed(1) : '–'}</Text><Text style={styles.ratingLabel}>SEEN · {community.count} RATINGS</Text></View></View>
          <Pressable style={styles.primary} onPress={() => router.push(`/log/${movie.id}`)}><Text style={styles.primaryText}>{entry?.status === 'seen' ? '✓ Edit SEEN entry' : '✓ Mark as SEEN'}</Text></Pressable>
          {entry?.status !== 'seen' ? <Pressable style={styles.secondary} onPress={addWatchlist}><Text style={styles.secondaryText}>{entry?.status === 'watchlist' ? '♥ In Watchlist' : '♡ Add to Watchlist'}</Text></Pressable> : null}
          <Text style={styles.section}>Story</Text><Text style={styles.overview}>{movie.overview || 'No description available.'}</Text>
          <View style={styles.ai}><Text style={styles.aiKicker}>SEEN AI</Text><Text style={styles.aiTitle}>Recall this movie</Text><View style={styles.aiTabs}>{(['spoiler_free','spoiler','ending'] as SummaryMode[]).map((m) => <Pressable key={m} onPress={() => loadAi(m)} style={[styles.aiTab, summaryMode===m && styles.aiTabActive]}><Text style={[styles.aiTabText, summaryMode===m && styles.aiTabTextActive]}>{m==='spoiler_free'?'Spoiler-free':m==='spoiler'?'With spoilers':'Explain ending'}</Text></Pressable>)}</View><Text style={styles.aiText}>{aiBusy ? 'Thinking…' : summary || 'Choose a mode to generate a short memory.'}</Text></View>
          {entry ? <Pressable style={styles.remove} onPress={remove}><Text style={styles.removeText}>Remove from library</Text></Pressable> : null}
        </View>
      </ScrollView>
    </View>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg }, loading: { color: colors.muted, marginTop: 100, textAlign: 'center' }, hero: { height: 280, backgroundColor: colors.surface2 }, overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(5,7,8,.42)' }, back: { marginLeft: 18, marginTop: 4, width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(8,10,11,.78)', borderWidth: 1, borderColor: 'rgba(255,255,255,.16)', alignItems: 'center', justifyContent: 'center' }, backText: { color: colors.text, fontSize: 34, lineHeight: 34 }, body: { padding: 20, marginTop: -35 }, heading: { flexDirection: 'row', alignItems: 'flex-end' }, poster: { width: 108, height: 160, borderRadius: 14, backgroundColor: colors.surface2 }, headingInfo: { flex: 1, paddingLeft: 14, paddingBottom: 4 }, title: { color: colors.text, fontSize: 27, fontWeight: '900', lineHeight: 31 }, meta: { color: colors.muted, fontSize: 12, marginTop: 5 }, director: { color: colors.text, fontSize: 12, fontWeight: '700', marginTop: 10 }, ratings: { flexDirection: 'row', gap: 10, marginTop: 18 }, ratingCard: { flex: 1, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 15, padding: 14 }, ratingValue: { color: colors.lime, fontSize: 24, fontWeight: '900' }, ratingLabel: { color: colors.muted, fontSize: 9, fontWeight: '800', marginTop: 4 }, primary: { backgroundColor: colors.lime, borderRadius: 14, padding: 15, alignItems: 'center', marginTop: 11 }, primaryText: { color: colors.black, fontWeight: '900' }, secondary: { borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, borderRadius: 14, padding: 14, alignItems: 'center', marginTop: 9 }, secondaryText: { color: colors.text, fontWeight: '800' }, section: { color: colors.text, fontSize: 19, fontWeight: '900', marginTop: 26 }, overview: { color: colors.muted, lineHeight: 22, marginTop: 8 }, ai: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 18, padding: 17, marginTop: 24 }, aiKicker: { color: colors.lime, fontSize: 10, fontWeight: '900', letterSpacing: 1.6 }, aiTitle: { color: colors.text, fontSize: 20, fontWeight: '900', marginTop: 4 }, aiTabs: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginTop: 14 }, aiTab: { borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingVertical: 8, paddingHorizontal: 9 }, aiTabActive: { backgroundColor: colors.lime, borderColor: colors.lime }, aiTabText: { color: colors.text, fontSize: 10, fontWeight: '800' }, aiTabTextActive: { color: colors.black }, aiText: { color: '#C7CDCF', lineHeight: 22, marginTop: 15 }, remove: { alignItems: 'center', padding: 18, marginTop: 8 }, removeText: { color: colors.danger, fontWeight: '800' },
});
