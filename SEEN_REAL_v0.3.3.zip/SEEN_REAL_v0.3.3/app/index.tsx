import { Redirect } from 'expo-router';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { useAuth } from '@/context/AuthContext';
import { isSupabaseConfigured } from '@/lib/supabase';
import { colors } from '@/theme';

export default function Index() {
  const { session, loading } = useAuth();
  if (!isSupabaseConfigured) return <Redirect href="/setup" />;
  if (loading) return <View style={styles.center}><ActivityIndicator color={colors.lime} /></View>;
  return <Redirect href={session ? '/(tabs)' : '/(auth)/login'} />;
}
const styles = StyleSheet.create({ center: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' } });
