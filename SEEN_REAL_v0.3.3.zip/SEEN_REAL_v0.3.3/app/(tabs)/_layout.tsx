import { Redirect, Tabs } from 'expo-router';
import { Text } from 'react-native';
import { useAuth } from '@/context/AuthContext';
import { colors } from '@/theme';

const Icon = ({ symbol, focused }: { symbol: string; focused: boolean }) => <Text style={{ color: focused ? colors.lime : colors.muted, fontSize: 18, fontWeight: '900' }}>{symbol}</Text>;

export default function TabsLayout() {
  const { session, loading } = useAuth();
  if (!loading && !session) return <Redirect href="/(auth)/login" />;
  return (
    <Tabs screenOptions={{ headerShown: false, tabBarStyle: { backgroundColor: '#0C0F10', borderTopColor: colors.border, height: 72, paddingTop: 8 }, tabBarActiveTintColor: colors.lime, tabBarInactiveTintColor: colors.muted, tabBarLabelStyle: { fontSize: 11, fontWeight: '700', marginBottom: 8 } }}>
      <Tabs.Screen name="index" options={{ title: 'Home', tabBarIcon: ({ focused }) => <Icon symbol="⌂" focused={focused} /> }} />
      <Tabs.Screen name="search" options={{ title: 'Search', tabBarIcon: ({ focused }) => <Icon symbol="⌕" focused={focused} /> }} />
      <Tabs.Screen name="movies" options={{ title: 'My Movies', tabBarIcon: ({ focused }) => <Icon symbol="▦" focused={focused} /> }} />
      <Tabs.Screen name="watchlist" options={{ title: 'Watchlist', tabBarIcon: ({ focused }) => <Icon symbol="♡" focused={focused} /> }} />
      <Tabs.Screen name="profile" options={{ title: 'Profile', tabBarIcon: ({ focused }) => <Icon symbol="○" focused={focused} /> }} />
    </Tabs>
  );
}
