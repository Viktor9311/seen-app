import { useCallback, useState } from 'react';
import { useFocusEffect, router } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MovieRow } from '@/components/MovieRow';
import { StatCard } from '@/components/StatCard';
import { getLibrary } from '@/lib/library';
import { popularMovies } from '@/lib/api';
import { colors } from '@/theme';
import { LibraryEntry, MovieSummary } from '@/types/movie';

export default function HomeScreen() {
  const [seen, setSeen] = useState<LibraryEntry[]>([]);
  const [popular, setPopular] = useState<MovieSummary[]>([]);

  useFocusEffect(useCallback(() => {
    getLibrary('seen').then(setSeen).catch(() => setSeen([]));
    popularMovies().then((m) => setPopular(m.slice(0, 5))).catch(() => setPopular([]));
  }, []));

  const avg = seen.length ? seen.reduce((s, x) => s + Number(x.user_rating || 0), 0) / seen.length : 0;
  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}><Text style={styles.logo}>SEEN</Text><View style={styles.dot} /></View>
        <Text style={styles.tagline}>Remember what you watched.</Text>
        <View style={styles.stats}><StatCard value={seen.length} label="Movies Seen" /><StatCard value={avg ? avg.toFixed(1) : '–'} label="Average Rating" /></View>
        <Pressable style={styles.primary} onPress={() => router.push('/(tabs)/search')}><Text style={styles.primaryText}>＋ Add movie</Text></Pressable>
        <Text style={styles.section}>Recently Seen</Text>
        {seen.slice(0, 3).map((entry) => <MovieRow key={entry.id} entry={entry} movie={{ id: entry.tmdb_id, title: entry.title, releaseDate: entry.release_date, posterPath: entry.poster_path }} />)}
        {!seen.length && <Text style={styles.empty}>Your history starts here.</Text>}
        <Text style={styles.section}>Popular now</Text>
        {popular.map((movie) => <MovieRow key={movie.id} movie={movie} />)}
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg }, content: { padding: 20, paddingBottom: 110 }, header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, logo: { color: colors.text, fontSize: 29, fontWeight: '900', letterSpacing: 4 }, dot: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.lime }, tagline: { color: colors.muted, marginTop: 8 }, stats: { flexDirection: 'row', gap: 11, marginTop: 22 }, primary: { backgroundColor: colors.lime, borderRadius: 14, padding: 15, alignItems: 'center', marginTop: 13 }, primaryText: { color: colors.black, fontWeight: '900' }, section: { color: colors.text, fontSize: 19, fontWeight: '900', marginTop: 28, marginBottom: 11 }, empty: { color: colors.muted, backgroundColor: colors.surface, borderRadius: 14, padding: 20, borderWidth: 1, borderColor: colors.border },
});
