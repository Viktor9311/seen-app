import { useCallback, useState } from 'react';
import { useFocusEffect } from 'expo-router';
import { ScrollView, StyleSheet, Text } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MovieRow } from '@/components/MovieRow';
import { getLibrary } from '@/lib/library';
import { colors } from '@/theme';
import { LibraryEntry } from '@/types/movie';

export default function WatchlistScreen() {
  const [items, setItems] = useState<LibraryEntry[]>([]);
  useFocusEffect(useCallback(() => { getLibrary('watchlist').then(setItems).catch(() => setItems([])); }, []));
  return <SafeAreaView style={styles.safe} edges={['top']}><Text style={styles.title}>Watchlist</Text><ScrollView contentContainerStyle={styles.list}>{items.map((entry) => <MovieRow key={entry.id} entry={entry} movie={{ id: entry.tmdb_id, title: entry.title, releaseDate: entry.release_date, posterPath: entry.poster_path }} />)}{!items.length && <Text style={styles.empty}>Save movies here for later.</Text>}</ScrollView></SafeAreaView>;
}
const styles = StyleSheet.create({ safe: { flex: 1, backgroundColor: colors.bg }, title: { color: colors.text, fontSize: 30, fontWeight: '900', paddingHorizontal: 20, paddingTop: 16 }, list: { padding: 20, paddingBottom: 110 }, empty: { color: colors.muted, marginTop: 50, textAlign: 'center' } });
