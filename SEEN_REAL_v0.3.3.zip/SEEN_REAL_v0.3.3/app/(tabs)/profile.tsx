import { useCallback, useState } from 'react';
import { useFocusEffect, router } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatCard } from '@/components/StatCard';
import { getLibrary } from '@/lib/library';
import { supabase } from '@/lib/supabase';
import { colors } from '@/theme';
import { LibraryEntry } from '@/types/movie';

export default function ProfileScreen() {
  const [items, setItems] = useState<LibraryEntry[]>([]);
  useFocusEffect(useCallback(() => { getLibrary('seen').then(setItems).catch(() => setItems([])); }, []));
  const avg = items.length ? items.reduce((s, x) => s + Number(x.user_rating || 0), 0) / items.length : 0;
  const platform = Object.entries(items.reduce<Record<string, number>>((a, x) => { if (x.where_watched) a[x.where_watched] = (a[x.where_watched] || 0) + 1; return a; }, {})).sort((a,b) => b[1]-a[1])[0]?.[0] || '—';
  async function logout() { await supabase?.auth.signOut(); router.replace('/(auth)/login'); }
  return <SafeAreaView style={styles.safe} edges={['top']}><ScrollView contentContainerStyle={styles.content}><Text style={styles.title}>Profile</Text><View style={styles.row}><StatCard value={items.length} label="Movies Seen" /><StatCard value={avg ? avg.toFixed(1) : '–'} label="Average Rating" /></View><View style={styles.card}><Text style={styles.kicker}>MOST USED</Text><Text style={styles.big}>{platform}</Text></View><View style={styles.card}><Text style={styles.kicker}>SEEN AI</Text><Text style={styles.cardTitle}>Your movie memory gets smarter.</Text><Text style={styles.body}>Film summaries are generated on the server and cached, so API keys never sit inside the app.</Text></View><Pressable style={styles.logout} onPress={logout}><Text style={styles.logoutText}>Sign out</Text></Pressable></ScrollView></SafeAreaView>;
}
const styles = StyleSheet.create({ safe: { flex: 1, backgroundColor: colors.bg }, content: { padding: 20, paddingBottom: 110 }, title: { color: colors.text, fontSize: 30, fontWeight: '900' }, row: { flexDirection: 'row', gap: 11, marginTop: 20 }, card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 16, padding: 18, marginTop: 12 }, kicker: { color: colors.lime, fontSize: 10, letterSpacing: 1.6, fontWeight: '900' }, big: { color: colors.text, fontSize: 22, fontWeight: '900', marginTop: 7 }, cardTitle: { color: colors.text, fontSize: 18, fontWeight: '900', marginTop: 7 }, body: { color: colors.muted, lineHeight: 21, marginTop: 8 }, logout: { marginTop: 26, alignItems: 'center', padding: 14 }, logoutText: { color: colors.danger, fontWeight: '800' } });
