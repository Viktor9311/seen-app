import { StyleSheet, Text, View } from 'react-native';
import { colors } from '@/theme';

export function StatCard({ value, label }: { value: string | number; label: string }) {
  return <View style={styles.card}><Text style={styles.value}>{value}</Text><Text style={styles.label}>{label}</Text></View>;
}
const styles = StyleSheet.create({
  card: { flex: 1, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 16, padding: 17 },
  value: { color: colors.lime, fontSize: 28, fontWeight: '900' },
  label: { color: colors.muted, fontSize: 12, marginTop: 4 },
});
