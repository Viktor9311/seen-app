import { Image } from 'expo-image';
import { router } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { posterUrl } from '@/lib/images';
import { colors } from '@/theme';
import { LibraryEntry, MovieSummary } from '@/types/movie';

export function MovieRow({ movie, entry }: { movie: MovieSummary; entry?: LibraryEntry }) {
  const uri = posterUrl(movie.posterPath, 'w342');
  return (
    <Pressable style={styles.row} onPress={() => router.push(`/movie/${movie.id}`)}>
      {uri ? <Image source={uri} style={styles.poster} contentFit="cover" transition={150} /> : <View style={[styles.poster, styles.blank]}><Text style={styles.blankText}>SEEN</Text></View>}
      <View style={styles.info}>
        <Text style={styles.title} numberOfLines={2}>{movie.title}</Text>
        <Text style={styles.meta}>{movie.releaseDate?.slice(0, 4) || '—'}</Text>
        {entry?.user_rating ? <Text style={styles.rating}>★ {Number(entry.user_rating).toFixed(1)} <Text style={styles.meta}>· {entry.where_watched}</Text></Text> : null}
        {!entry && movie.communityRating ? <Text style={styles.rating}>★ {movie.communityRating.toFixed(1)} community</Text> : null}
      </View>
      <Text style={styles.arrow}>›</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 16, padding: 10, marginBottom: 11 },
  poster: { width: 64, height: 96, borderRadius: 10, backgroundColor: colors.surface2 },
  blank: { alignItems: 'center', justifyContent: 'center' },
  blankText: { color: colors.muted, fontSize: 10, fontWeight: '900', letterSpacing: 1 },
  info: { flex: 1 },
  title: { color: colors.text, fontSize: 16, fontWeight: '800' },
  meta: { color: colors.muted, fontSize: 12, marginTop: 4 },
  rating: { color: colors.lime, fontWeight: '900', fontSize: 13, marginTop: 7 },
  arrow: { color: colors.muted, fontSize: 26, paddingHorizontal: 5 },
});
