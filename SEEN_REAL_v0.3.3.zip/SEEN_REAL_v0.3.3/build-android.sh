#!/data/data/com.termux/files/usr/bin/bash
set -e
printf '\nSEEN Android Build\n==================\n'
npm install
printf '\nJetzt bei Expo anmelden.\n'
npx eas-cli login
printf '\nStarte APK-Cloud-Build...\n'
npx eas-cli build --platform android --profile preview
