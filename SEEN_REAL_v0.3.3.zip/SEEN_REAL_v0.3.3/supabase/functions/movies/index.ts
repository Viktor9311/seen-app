const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const TMDB_BASE = 'https://api.themoviedb.org/3';
const token = Deno.env.get('TMDB_READ_TOKEN');

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
}

async function tmdb(path: string) {
  if (!token) throw new Error('TMDB_READ_TOKEN is not configured');
  const res = await fetch(`${TMDB_BASE}${path}`, { headers: { Authorization: `Bearer ${token}`, accept: 'application/json' } });
  if (!res.ok) throw new Error(`TMDB ${res.status}`);
  return res.json();
}

function summary(m: any) {
  return {
    id: m.id,
    title: m.title,
    releaseDate: m.release_date || null,
    posterPath: m.poster_path || null,
    backdropPath: m.backdrop_path || null,
    overview: m.overview || '',
  };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const body = await req.json();
    if (body.action === 'search') {
      const query = String(body.query || '').trim();
      if (!query) return json({ movies: [] });
      const data = await tmdb(`/search/movie?query=${encodeURIComponent(query)}&include_adult=false&language=de-DE&region=DE&page=1`);
      return json({ movies: (data.results || []).slice(0, 30).map(summary) });
    }
    if (body.action === 'popular') {
      const data = await tmdb('/trending/movie/week?language=de-DE');
      return json({ movies: (data.results || []).slice(0, 12).map(summary) });
    }
    if (body.action === 'details') {
      const id = Number(body.id);
      if (!id) return json({ error: 'Missing id' }, 400);
      const m = await tmdb(`/movie/${id}?language=de-DE&append_to_response=credits`);
      const director = (m.credits?.crew || []).find((p: any) => p.job === 'Director')?.name || null;
      return json({ movie: { ...summary(m), runtime: m.runtime || null, genres: (m.genres || []).map((g: any) => g.name), director, tmdbRating: m.vote_average ? Number(m.vote_average) : null } });
    }
    return json({ error: 'Unknown action' }, 400);
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : 'Unknown error' }, 500);
  }
});
