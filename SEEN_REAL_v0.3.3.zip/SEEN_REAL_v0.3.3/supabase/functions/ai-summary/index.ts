import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const TMDB_TOKEN = Deno.env.get('TMDB_READ_TOKEN');
const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');
const OPENAI_MODEL = Deno.env.get('OPENAI_MODEL') || 'gpt-5.6-luna';
const admin = createClient(SUPABASE_URL, SERVICE_KEY);

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
}

async function verifyUser(req: Request) {
  const auth = req.headers.get('Authorization');
  if (!auth) return false;
  const token = auth.replace('Bearer ', '');
  const { data, error } = await admin.auth.getUser(token);
  return !error && Boolean(data.user);
}

async function fetchMovie(id: number) {
  if (!TMDB_TOKEN) throw new Error('TMDB_READ_TOKEN is not configured');
  const r = await fetch(`https://api.themoviedb.org/3/movie/${id}?language=de-DE`, { headers: { Authorization: `Bearer ${TMDB_TOKEN}`, accept: 'application/json' } });
  if (!r.ok) throw new Error(`TMDB ${r.status}`);
  return r.json();
}

function instructions(mode: string) {
  if (mode === 'spoiler') return 'Fasse die gesamte Handlung inklusive wichtiger Wendungen und Ende in 120 bis 180 deutschen Wörtern zusammen. Klar, natürlich und präzise.';
  if (mode === 'ending') return 'Erkläre das Ende des Films in 120 bis 180 deutschen Wörtern. Nenne entscheidende Wendungen und was das Ende bedeutet. Keine unnötigen Einleitungen.';
  return 'Fasse den Film spoilerfrei in 70 bis 110 deutschen Wörtern zusammen. Keine zentralen Wendungen oder das Ende verraten. Natürlich und präzise formulieren.';
}

function extractText(data: any) {
  for (const item of data.output || []) {
    if (item.type !== 'message') continue;
    for (const content of item.content || []) if (content.type === 'output_text' && content.text) return content.text;
  }
  return '';
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (!(await verifyUser(req))) return json({ error: 'Unauthorized' }, 401);
  try {
    const { tmdbId, mode = 'spoiler_free' } = await req.json();
    const id = Number(tmdbId);
    if (!id || !['spoiler_free','spoiler','ending'].includes(mode)) return json({ error: 'Invalid input' }, 400);

    const { data: cached } = await admin.from('ai_summaries').select('summary').eq('tmdb_id', id).eq('mode', mode).maybeSingle();
    if (cached?.summary) return json({ summary: cached.summary, cached: true });

    if (!OPENAI_API_KEY) return json({ error: 'OPENAI_API_KEY is not configured' }, 503);
    const movie = await fetchMovie(id);
    const prompt = `Film: ${movie.title} (${String(movie.release_date || '').slice(0,4)})\nOffizielle Kurzbeschreibung: ${movie.overview || 'Keine.'}\n\n${instructions(mode)}`;

    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: OPENAI_MODEL, instructions: 'Du bist die Erinnerungsfunktion einer Film-App namens SEEN. Antworte nur mit der gewünschten Zusammenfassung.', input: prompt, max_output_tokens: 500 }),
    });
    if (!response.ok) throw new Error(`OpenAI ${response.status}: ${await response.text()}`);
    const data = await response.json();
    const summary = extractText(data);
    if (!summary) throw new Error('OpenAI returned no text');

    await admin.from('ai_summaries').upsert({ tmdb_id: id, mode, summary, updated_at: new Date().toISOString() });
    return json({ summary, cached: false });
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : 'Unknown error' }, 500);
  }
});
