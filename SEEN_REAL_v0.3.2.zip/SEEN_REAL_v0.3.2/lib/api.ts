import { MovieDetails, MovieSummary, SummaryMode } from '@/types/movie';

type ITunesMovie = {
  trackId: number;
  trackName: string;
  releaseDate?: string;
  artworkUrl100?: string;
  primaryGenreName?: string;
  trackTimeMillis?: number;
  longDescription?: string;
  shortDescription?: string;
  artistName?: string;
};

const SEARCH = 'https://itunes.apple.com/search';
const LOOKUP = 'https://itunes.apple.com/lookup';

function artwork(url?: string) {
  if (!url) return null;
  return url.replace(/100x100bb/i, '600x900bb').replace(/100x100/i, '600x900');
}

function summary(m: ITunesMovie): MovieSummary {
  return {
    id: m.trackId,
    title: m.trackName,
    releaseDate: m.releaseDate ?? null,
    posterPath: artwork(m.artworkUrl100),
    backdropPath: artwork(m.artworkUrl100),
    overview: m.longDescription || m.shortDescription || '',
  };
}

function details(m: ITunesMovie): MovieDetails {
  return {
    ...summary(m),
    runtime: m.trackTimeMillis ? Math.round(m.trackTimeMillis / 60000) : null,
    genres: m.primaryGenreName ? [m.primaryGenreName] : [],
    director: m.artistName || null,
    tmdbRating: null,
  };
}

async function getJson(url: string) {
  const response = await fetch(url, {
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`Movie service error (${response.status})`);
  return response.json();
}

export async function searchMovies(query: string): Promise<MovieSummary[]> {
  const params = new URLSearchParams({
    term: query,
    country: 'DE',
    media: 'movie',
    entity: 'movie',
    limit: '30',
  });
  const data = await getJson(`${SEARCH}?${params.toString()}`);
  const results = (data?.results ?? []) as ITunesMovie[];
  return results.filter((m) => m.trackId && m.trackName).map(summary);
}

export async function popularMovies(): Promise<MovieSummary[]> {
  const titles = ['Dune', 'Interstellar', 'Gladiator', 'The Dark Knight'];
  const batches = await Promise.all(
    titles.map(async (title) => {
      try {
        const found = await searchMovies(title);
        return found[0] ?? null;
      } catch {
        return null;
      }
    })
  );
  return batches.filter(Boolean) as MovieSummary[];
}

export async function getMovieDetails(id: number): Promise<MovieDetails> {
  const params = new URLSearchParams({ id: String(id), country: 'DE', entity: 'movie' });
  const data = await getJson(`${LOOKUP}?${params.toString()}`);
  const movie = (data?.results ?? []).find((m: ITunesMovie) => Number(m.trackId) === id) as ITunesMovie | undefined;
  if (!movie) throw new Error('Film wurde nicht gefunden.');
  return details(movie);
}

export async function getAiSummary(id: number, mode: SummaryMode): Promise<string> {
  const movie = await getMovieDetails(id);
  const overview = movie.overview?.trim();
  if (!overview) return 'Für diesen Film ist aktuell noch keine Zusammenfassung verfügbar.';
  if (mode === 'spoiler_free') return overview;
  if (mode === 'spoiler') return `${overview}\n\nDie ausführliche SEEN-AI-Spoilerzusammenfassung wird in einem späteren Build aktiviert.`;
  return `${overview}\n\nDie Funktion „Ende erklären“ wird im nächsten SEEN-AI-Ausbauschritt aktiviert.`;
}
