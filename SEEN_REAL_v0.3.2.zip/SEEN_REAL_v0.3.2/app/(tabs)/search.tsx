import { useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MovieRow } from '@/components/MovieRow';
import { searchMovies } from '@/lib/api';
import { colors } from '@/theme';
import { MovieSummary } from '@/types/movie';

export default function SearchScreen() {
  const [query, setQuery] = useState('');
  const [movies, setMovies] = useState<MovieSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function run() {
    if (!query.trim()) return;
    setLoading(true); setError('');
    try { setMovies(await searchMovies(query.trim())); }
    catch (e: any) { setError(e?.message || 'Search failed.'); }
    finally { setLoading(false); }
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}><Text style={styles.title}>Search</Text><Text style={styles.kicker}>REAL MOVIE DATA</Text></View>
      <View style={styles.search}><TextInput value={query} onChangeText={setQuery} onSubmitEditing={run} returnKeyType="search" placeholder="Gladiator, Dune, Batman…" placeholderTextColor={colors.muted} style={styles.input} /><Pressable onPress={run} style={styles.button}><Text style={styles.buttonText}>Search</Text></Pressable></View>
      {loading ? <ActivityIndicator color={colors.lime} style={{ marginTop: 30 }} /> : null}
      {error ? <Text style={styles.error}>{error}</Text> : null}
      <ScrollView contentContainerStyle={styles.list} keyboardShouldPersistTaps="handled">{movies.map((m) => <MovieRow key={m.id} movie={m} />)}</ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg }, header: { padding: 20, paddingBottom: 4 }, title: { color: colors.text, fontSize: 30, fontWeight: '900' }, kicker: { color: colors.lime, fontSize: 10, fontWeight: '900', letterSpacing: 1.6, marginTop: 4 }, search: { flexDirection: 'row', gap: 8, paddingHorizontal: 20, paddingTop: 10 }, input: { flex: 1, backgroundColor: colors.surface, color: colors.text, borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: 14 }, button: { backgroundColor: colors.lime, paddingHorizontal: 15, alignItems: 'center', justifyContent: 'center', borderRadius: 14 }, buttonText: { color: colors.black, fontWeight: '900' }, list: { padding: 20, paddingBottom: 110 }, error: { color: colors.danger, paddingHorizontal: 20, paddingTop: 14 },
});
